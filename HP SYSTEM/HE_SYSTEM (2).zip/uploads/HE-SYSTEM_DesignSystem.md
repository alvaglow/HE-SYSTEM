# HE-SYSTEM Design System
**Happy English Platform — Frontend Design Language**
*Version 1.0 — June 2026*

---

## 1. Brand Identity

### Core Brand Values
HE-SYSTEM is **professional, trustworthy, and motivating**. The design language communicates academic rigor, financial transparency, and growth through a clear hierarchy of blue (authority), red (urgency/action), and gold (achievement/reward).

### Logo Usage
- **Wordmark:** `HE` in blue `#1B3D8C` + `-SYSTEM` in red `#DC2626` (Oswald 700)
- **Icon:** Blue square background, gold top stripe, red bottom bar, white HE lettermark
- **Minimum size:** 120px wide for wordmark, 24px for icon
- **Clear space:** Equal to icon height on all sides
- **Don't:** Rotate, recolor, or use on busy backgrounds without overlay

---

## 2. Color System

### Brand Colors
| Token | Hex | Usage |
|-------|-----|-------|
| `he-blue` | `#1B3D8C` | Primary actions, nav, headings |
| `he-blue-light` | `#2E5FCC` | Hover states |
| `he-blue-50` | `#EEF2FF` | Tinted backgrounds, secondary buttons |
| `he-blue-100` | `#C7D2FE` | Hover on secondary |
| `he-red` | `#DC2626` | Alerts, overdue, brand accent |
| `he-red-50` | `#FEE2E2` | Danger backgrounds |
| `he-gold` | `#F59E0B` | Achievement, tier badges, rewards |
| `he-gold-50` | `#FEF3C7` | Gold tinted backgrounds |
| `he-black` | `#0F172A` | Body text, management portal bg |

### Semantic Colors
| Token | Hex | Usage |
|-------|-----|-------|
| Success | `#16A34A` | Paid, present, A-grade |
| Success Bg | `#DCFCE7` | Success alert backgrounds |
| Warning | `#D97706` | Late, C-grade, low attendance |
| Warning Bg | `#FEF3C7` | Warning alert backgrounds |
| Info | `#0EA5E9` | Informational alerts |
| Info Bg | `#E0F2FE` | Info alert backgrounds |

### Neutral Scale (Slate)
`50 → 100 → 200 → 300 → 400 → 500 → 600 → 700 → 800 → 900`
`#F8FAFC → #F1F5F9 → #E2E8F0 → #CBD5E1 → #94A3B8 → #64748B → #475569 → #334155 → #1E293B → #0F172A`

---

## 3. Typography

### Font Families
- **Display (headings):** Oswald — loaded via `next/font/google`
- **Body:** Inter — loaded via `next/font/google`
- **Monospace:** JetBrains Mono — for OTP codes, invoice numbers, IDs

### Scale
| Name | Size | Weight | Font | Use |
|------|------|--------|------|-----|
| Display XL | 40px / 800 | Oswald | Page hero titles |
| Display LG | 32px / 800 | Oswald | Section titles |
| Display MD | 24px / 700 | Oswald | Card titles |
| Display SM | 20px / 700 | Oswald | Sub-headings |
| Body LG | 16px / 400–500 | Inter | Long-form text |
| Body MD | 14px / 400 | Inter | Standard UI text |
| Body SM | 13px / 400 | Inter | Secondary text |
| Label LG | 14px / 600 | Inter | Form labels |
| Label SM | 12px / 600 | Inter | Field hints |
| Overline | 11px / 700 + 1px tracking | Inter | Section labels (ALL CAPS) |

---

## 4. Spacing

Based on a 4px grid:
`4 → 8 → 12 → 16 → 20 → 24 → 32 → 40 → 48 → 64px`

- **Component padding:** 16px (cards), 12px (compact), 24px (page sections)
- **Gap between elements:** 8px (tight), 12px (standard), 16px (loose)
- **Page gutter:** 24px mobile, 32px tablet, 48px desktop

---

## 5. Border Radius
| Token | Value | Use |
|-------|-------|-----|
| xs | 4px | Tiny elements, progress bars |
| sm | 6px | Buttons XS, tags |
| md | 8px | Inputs, small cards |
| lg | 10px | Standard buttons |
| xl | 12px | Cards, modals |
| 2xl | 16px | Large cards, panels |
| 3xl | 20px | Feature sections |
| full | 9999px | Pills, avatar circles |

---

## 6. Elevation (Shadows)
| Name | Value | Use |
|------|-------|-----|
| sm | `0 1px 3px rgba(0,0,0,0.08)` | Cards, inputs |
| md | `0 4px 12px rgba(0,0,0,0.10)` | Dropdowns, popovers |
| lg | `0 8px 24px rgba(0,0,0,0.12)` | Modals, drawers |
| xl | `0 20px 48px rgba(0,0,0,0.16)` | Floating panels |
| brand | `0 4px 16px rgba(27,61,140,0.20)` | Focused primary elements |

---

## 7. Core Components

### Button
**File:** `components/ui/button.tsx`

| Variant | Use |
|---------|-----|
| `primary` | Main actions (Save, Submit, Enroll) |
| `secondary` | Alternative actions (View, Filter) |
| `ghost` | Tertiary actions, icon buttons |
| `outline` | Bordered, less visual weight |
| `gold` | Achievement actions (Claim Bonus, Payout) |
| `danger` | Destructive actions (Delete, Reject) |
| `dark` | On light backgrounds in management portal |

**Sizes:** `xs` (24px) → `sm` (32px) → `md` (36px) → `lg` (44px)

### Input
**File:** `components/ui/input.tsx`
- States: `default | focus | error | success | disabled`
- Supports: `label`, `hint`, `error`, `leftIcon`, `rightIcon`
- Always use `required` prop for mandatory fields

### Card
**File:** `components/ui/card.tsx`
- `accent` prop adds colored top border: `blue | red | gold | green`
- `hoverable` adds lift animation on hover
- Subcomponents: `CardHeader`, `CardTitle`, `CardSubtitle`, `CardFooter`

### Badge
**File:** `components/ui/badge.tsx`
- Status variants: `blue | red | gold | green | slate | dark`
- Outline variants: `outline-blue | outline-red`
- Use `dot` prop for status indicator dot

### Avatar
**File:** `components/ui/avatar.tsx`
- Auto-generates initials from `name` prop
- Falls back to initials if image fails to load
- Color is deterministically derived from name (same person = same color always)

### Modal
**File:** `components/ui/modal.tsx`
- Close on Escape key + overlay click (disable with `persistent`)
- Locks body scroll when open
- Sizes: `sm | md | lg | xl | full`
- Pass JSX to `footer` for action buttons

### Toast
**File:** `components/ui/toast.tsx`
- Wrap app in `<ToastProvider>`
- Use `useToast()` hook → call `toast.toast({ type, title, message })`
- Auto-dismiss after 4s (configure with `duration`)

---

## 8. Domain Components

### StatCard
**File:** `components/ui/stat-card.tsx`
- Four accents matching KPI categories: `blue | red | gold | green`
- Props: `icon`, `value`, `label`, `trend`
- Loading skeleton included

### KpiPillar
**File:** `components/ui/kpi-pillar.tsx`
- Shows pillar name, weight %, score (0–100), letter grade, progress bar
- Grade colors: A=green, B=blue, C=yellow, D=orange, F=red
- Shows weighted contribution in points

### TierBadge
**File:** `components/ui/tier-badge.tsx`
- Five tiers: `starter | bronze | silver | gold | platinum`
- `TIER_CONFIG` exports all tier metadata (label, emoji, rate, student range)
- `TierProgress` component shows progress bar + next-tier info

### AttendanceBadge
**File:** `components/ui/attendance-badge.tsx`
- Four statuses: `present | absent | late | excused`
- `AttendanceRate` component color-codes the percentage (≥80% green, ≥65% amber, <65% red)

---

## 9. Portal Design Guidelines

### Student Portal
- **Accent:** Blue (`#1B3D8C`)
- **Header:** Blue gradient with glass-style widgets for key stats
- **Tone:** Encouraging, personal, progress-focused
- **Nav:** Bottom tab bar on mobile; left sidebar on desktop

### Teacher Portal
- **Accent:** Blue + Gold for KPI achievement
- **Header:** Clean white with KPI score prominent top-right
- **Tone:** Professional, task-oriented
- **Key patterns:** KPI pillars grid, OTP code display, attendance table

### Partner Portal
- **Accent:** Blue-to-Gold gradient
- **Header:** Gradient card showing tier badge + total earnings
- **Tone:** Motivational, gamified, reward-focused
- **Key patterns:** Tier progress bar, commission breakdown, leaderboard

### Admin Portal
- **Accent:** Blue
- **Tone:** Functional, dense, efficient
- **Key patterns:** Data tables, bulk actions, quick filters, status chips

### Management Portal
- **Theme:** Dark sidebar (`#0F172A`) + light main area
- **Accent:** Blue + Gold metrics
- **Tone:** Executive, analytical, overview-first
- **Key patterns:** Stat grid, trend charts, alert banners, export buttons

### Parent Portal
- **Accent:** Blue + Green (positive/healthy)
- **Tone:** Reassuring, transparent, simple
- **Key patterns:** Child switcher, attendance summary, fee status card

---

## 10. Animation Principles
- **Duration:** 150ms (micro), 200ms (transitions), 300ms (overlays)
- **Easing:** `cubic-bezier(0.4, 0, 0.2, 1)` for smooth; `cubic-bezier(0.34, 1.56, 0.64, 1)` for spring (modals, badges)
- **Progress bars:** 500ms ease-out on mount
- **Don't animate:** Color changes on hover (use instant), large layout shifts

---

## 11. Accessibility
- Minimum contrast ratio: 4.5:1 (AA) for all text
- Focus rings: `focus-visible:ring-2` on all interactive elements
- All form inputs have associated labels
- Modals trap focus and restore on close
- Color is never the only indicator (always paired with text/icon)
- Touch targets: minimum 44×44px

---

*Generated: June 2026 | HE-SYSTEM v1.0*
